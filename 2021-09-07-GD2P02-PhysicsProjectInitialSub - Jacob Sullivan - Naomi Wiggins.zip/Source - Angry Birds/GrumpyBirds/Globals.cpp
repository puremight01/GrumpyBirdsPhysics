#include"Globals.h"
sf::RenderWindow* Globals::window = nullptr;
Globals::Globals()
{
}