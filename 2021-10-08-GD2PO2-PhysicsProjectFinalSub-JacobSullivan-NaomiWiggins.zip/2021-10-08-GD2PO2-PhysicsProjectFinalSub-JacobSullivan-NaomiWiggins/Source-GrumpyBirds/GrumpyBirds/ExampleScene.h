#pragma once

#ifndef __Example_Scene__
#define __Example_Scene__

#include "Scene.h"

//This is a testing scene used as an example for how to create a scene 
//created by Jacob Sullivan
class ExampleScene : public Scene
{
public:
    //this constuctor is all that need to be created for the scene 
    //created by Jacob Sullivan
    ExampleScene();
};

#endif