#include"Globals.h"
sf::RenderWindow* Globals::window = nullptr;
sf::CircleShape* Globals::lineProjection[10] = { nullptr, nullptr, nullptr , nullptr , nullptr, nullptr, nullptr , nullptr , nullptr, nullptr };
Globals::Globals()
{
}