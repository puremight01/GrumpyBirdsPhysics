Grumpy Birds - Jacob Sullivan, Naomi Wiggins

Controls:
Using a mouse, with the left button pressed down, drag the mouse across the screen to launch the bird in the 
opposite direction of the mouse drag. Bird is launched on the release of the left mouse button. To reload the
slingshot / shoot another bird, just repeat the left mouse drag and the bird will appear in the slingshot.