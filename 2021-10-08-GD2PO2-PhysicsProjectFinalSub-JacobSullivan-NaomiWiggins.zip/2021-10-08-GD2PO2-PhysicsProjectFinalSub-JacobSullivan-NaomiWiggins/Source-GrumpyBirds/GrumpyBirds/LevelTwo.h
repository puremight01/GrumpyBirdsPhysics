#pragma once

#ifndef __Level_Two__
#define __Level_Two__

#include "Scene.h"

class LevelTwo : public Scene
{
public:
	//this constuctor builds level two
    //created by Jacob Sullivan
	LevelTwo();
};

#endif // !__Level_Two__